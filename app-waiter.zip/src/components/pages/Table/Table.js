// import styles from './Table.module.scss';
import { useSelector } from 'react-redux';
import { getOneTable } from '../../../redux/tablesRedux'



const Table = props => {

    const tableActiv = useSelector(state => getOneTable(state, 4));
    console.log(tableActiv);
    
    return (
        <div>
            <h1>Table</h1>

        </div>
    );
}; 

export default Table;