// import styles from './NotFound.module.scss';

const NotFound = () => {

    return(
        <div>
            <h1>404 Not found</h1>
        </div>
    )
};

export default NotFound;