import NavBar from "../NavBar/NavBar";

const Header = props => {
    return (
        <div>
            <NavBar />

        </div>
    );
};

export default Header;