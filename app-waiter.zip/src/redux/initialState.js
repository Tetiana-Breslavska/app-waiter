const initialState = {
    tables: [],


};

export default initialState;